1. Use the class  bred or bbrown or bgreen or byellow or bblue or borange to add background color.
2. Use class "bold" to creat bold text.
3. Add class "wblack" along with "widget" class for black widget.
4. Only call the graph/charts in the page where it is needed.
5. If you like to add jQuery Uniform style to forms, then add the class "uni" to the form.
6. Which working on Graphs and Charts take a look at jQuery Flot Official site - http://www.flotcharts.org
7. While working on sparklines take a look at official site of Sparklines - http://omnipotent.net/jquery.sparkline